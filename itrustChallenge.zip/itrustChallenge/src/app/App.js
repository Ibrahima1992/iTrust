import React from 'react';
import './App.css';

import { Container } from 'react-bootstrap';

import Event from './components/event'

function App() {
  return (
    <Container>
        <Event />
    </Container>
  )
}

export default App;
